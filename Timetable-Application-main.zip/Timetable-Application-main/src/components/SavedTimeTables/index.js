import SavedTimeTables from "./SavedTimeTables";

export default SavedTimeTables;
