import AddDetails from "./AddDetails";

export default AddDetails;
